pre_start_action() {
  : # No-op
}

post_start_action() {
  : # No-op
}
